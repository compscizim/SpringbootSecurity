package com.compscizimsecurity.compscizimsecurity;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CompscizimsecurityApplication {

	public static void main(String[] args) {
		SpringApplication.run(CompscizimsecurityApplication.class, args);
	}

}
