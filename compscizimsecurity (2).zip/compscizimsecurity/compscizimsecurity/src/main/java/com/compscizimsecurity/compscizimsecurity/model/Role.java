package com.compscizimsecurity.compscizimsecurity.model;

public enum Role {
    ADMIN,
    USER
}
